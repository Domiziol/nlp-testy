# nlp-roberta-project-2024l
Projekt NLP semestr 2024L - temat ROBERTA.

https://staff.elka.pw.edu.pl/~pandrusz/nlp_tematy.html

###### Autorzy
- Konrad Dumin
- Dominika Ziółkiewicz

